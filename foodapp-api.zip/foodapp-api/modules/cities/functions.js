'use strict';
import Cities  from '../../library/database/mongo/models/cities';

const getInfoCity = async (_id, _column) => {
    return await Countries.findOne({ _id: _id, status: 1 },_column);
};

const getCountries = async () => {
    const data = await Countries.find({ type: 0, status: 1 }).populate({
        path: 'cities',
        match: { status: 1 },
    }).populate({
        path: 'province',
        match: { status: 1 },
    });
    return data.map(country => country.toObject());
};

const getCountriesDiscover = async () => {
    const data = await Cities.find({ type: 1, statusDiscover: 1 }).populate({
        path: 'countries',
        match: { statusDiscover: 1 },
    });
    return data.map(country => country.toObject());
};

const createCountry = async (_data) => {
    return await Countries.create(_data);
};

const count = async () => {
    return await Cities.count({});
};


const getCity = async (_options) => {
    let countries = await Cities.aggregate([
            { $match: {country: { $ne: null }} },
            { $group : {
                    _id : '$country',
                    sub: { $push: "$$ROOT" }
                } },
        ]);
    let cities = await Cities.find({status: true, country: null}).limit(_options.limit).skip((_options.page - 1) * _options.limit);
    return [...countries, ...cities];
};

const getCityFrom = async (_options) => {
    if (!_options || !_options.filter) return null;
    switch (_options.filter) {
        case 'in':
            let query = { status: 1, type: 1 };
            if (_options.value) query._id = _options.value;
            return await Cities.find(query);
        case 'all':
            return await Cities.find({ status: 1, type: 1 }).populate({
                path: 'province',
                match: { status: 1 },
            });
        case 'id':
            return await Countries.findOne({
                type: 0,
                status: 1,
                _id: _options.value,
            }).populate({
                path: 'cities',
                match: { status: 1 },
                populate: { path: 'province', match: { status: 1 } },
            });
    }
};

export {count, createCountry, getCityFrom, getCountries, getInfoCity, getCity, getCountriesDiscover };
