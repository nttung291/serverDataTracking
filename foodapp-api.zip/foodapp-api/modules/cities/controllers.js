import $fn from '../functions';
import _ from 'lodash';
import mongoose from 'mongoose';
import configs from '../../config';


/**
 * API GET COUNTRIES DISCOVER
 * @route GET /api/countries/discover
 * @group Countries - Operations about Countries
 * @returns {object} 200 - An array of user info
 * @returns {Error}  default - Unexpected error
 */
export const getCountriesDiscover = async (req, res, next) => {
    try {
        const [err, countries] = await $fn.helpers.wait($fn.countries.getCountriesDiscover());
        if (err) return $fn.response.serverError(res, err);
        return $fn.response.success(res, countries);
    } catch (e) {
        console.log(e);
        return $fn.response.serverError(res, e);
    }
};

/**
 * API GET COUNTRIES
 * @route GET /api/countries
 * @group Countries - Operations about Countries
 * @returns {object} 200 - An array of user info
 * @returns {Error}  default - Unexpected error
 */
export const getCountries = async (req, res, next) => {
    try {
        const [err, countries] = await $fn.helpers.wait($fn.countries.getCountries());
        // const [err, countries] = await $fn.helpers.wait($fn.countries.createCountry({
        //     name: 'China Province',
        //     description: 'China Province',
        //     areaCode: '+86',
        //     type: 0,
        //     parentId: '5cb58bd3ca2114445d57392b',
        // }));
        if (err) return $fn.response.serverError(res, err);
        return $fn.response.success(res, countries);
    } catch (e) {
        console.log(e);
        return $fn.response.serverError(res, e);
    }
};


/**
 * API GET CITES
 * @route POST /api/city
 * @group Countries - Operations about Countries
 * @param {string} param.body.required - {"page":1,"limit": 10}
 * @returns {object} 200 - An array of user info
 * @returns {Error}  default - Unexpected error
 */
export const getCity = async (req, res, next) => {
    try {
        let _data = _.pick(req.body, [
            'page',
            'limit',
        ]);
        const [err, province] = await $fn.helpers.wait($fn.cities.getCity(_data));
        const [errCount, count] = await $fn.helpers.wait($fn.cities.count());
        if (errCount) return $fn.response.serverError(res, errCount);
        if (err) return $fn.response.serverError(res, err);
        return $fn.response.success(res, province ,count ,_data.limit);
    } catch (e) {
        console.log(e);
        return $fn.response.serverError(res, e);
    }
};


// /**
//  *
//  * @route GET /api/{city}/province
//  * @group City - Operations about City
//  * @param {string} query.body.required - {"password":"xxxxxxxxx"}
//  * @returns {object} 200 - An array of user info
//  * @returns {Error}  default - Unexpected error
//  */
// export const getProvinceByCity = async (req, res, next) => {
//   // try {
//   //   const [err, cities] = await $fn.helpers.wait($fn.city.getCities());
//   //   if (err) return $fn.response.serverError(res, err);
//   //   return $fn.response.success(res, cities);
//   // } catch (e) {
//   //   console.log(e);
//   //   return $fn.response.serverError(res, e);
//   // }
// };
