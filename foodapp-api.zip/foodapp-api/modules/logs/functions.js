'use strict';
import Logs  from '../../library/database/mongo/models/log_page';

const getPageCrawl = async () => {
    return await Logs.findOne({ loop: true });
};

const restartPage = async (_id) => {
    return await Logs.findOneAndUpdate({ _id: _id },{ page: 1 });
};

const nextPage = async (_option) => {
    return await Logs.findOneAndUpdate({ _id: _option.id },{ page: _option.page });
};

const disableCrawl = async (_id) => {
    return await Logs.findOneAndUpdate({ _id: _id },{ loop: false });
};

export {getPageCrawl, restartPage, disableCrawl, nextPage};
