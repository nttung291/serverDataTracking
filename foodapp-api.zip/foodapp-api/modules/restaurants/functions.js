'use strict';
import Restaurants  from '../../library/database/mongo/models/restaurants';
import configs from '../../config';
import request from 'request';
import utf8 from 'utf8';
import Cities from "../../library/database/mongo/models/cities";

const getRestaurants = async (_option) => {
    return await Restaurants.find(_option).populate({
        path: 'city_id',
        select: 'name',
    });
};

const getRestaurantsCrawl = async (_option) => {
    return await Restaurants.find({}).limit(_option.limit).skip((_option.page - 1) * _option.limit);
};

const updateGGstar = async (_option) => {
    return await Restaurants.findOneAndUpdate({ _id: _option.id },{ ggrating: _option.ggrating });
};


const getById = async (_id) => {
    return await Restaurants.findOne({_id : _id});
};

const countAll = async () => {
    return await Restaurants.countDocuments({});
};

const getFilterMenu = async (_city_id ,_limit) => {
    let random = await Restaurants.findOne({city_id : _city_id});
    let total = await Restaurants.aggregate([
        { $match: {city_id: _city_id ,cuisine : { $ne: "" }} },
        { $group : {
                _id : '$cuisine',
            } },
        {
            $count: "total"
        }
    ]);

    let cuisine = await Restaurants.aggregate([
        { $match: {city_id: _city_id ,cuisine : { $nin: [null,0,""] }} },
        { $group : {
                _id : '$cuisine',
            } },
        { $limit : _limit }
    ]);
    let type = await Restaurants.aggregate([
        { $match: {city_id: _city_id, type : { $ne: "" }} },
        { $group : {
                _id : '$type',
            } },
    ]);
    let ggrating = await Restaurants.aggregate([
        { $match: {city_id: _city_id, ggrating : { $nin: [null,0,""] }} },
        { $group : {
                _id : '$ggrating',
            } },
    ]);

    return {totalCuisine : total[0].total,
            cuisine : cuisine,
            type : type ,
            ggrating : ggrating,
            latCity : random.lat ,
            lngCity : random.lng,
            city_id : random.city_id,
    };
};

const getFromGoogle = async (_address) => {
    return request('https://maps.googleapis.com/maps/api/place/textsearch/json?query='+ utf8.encode(_address) +'&key='+configs.google.apikey
        , async (error, response, body) => {
            if (!error && response.statusCode == 200 && JSON.parse(body).results[0]) {
                let data = JSON.parse(body)
                await request('https://maps.googleapis.com/maps/api/place/details/json?reference='+data.results[0].place_id+'&sensor=true&key='+configs.google.apikey
                    , async (_error, _response, _body) => {
                        if (!error && _response.statusCode == 200) {
                            //console.log(JSON.parse(_body));
                            return JSON.parse(_body)
                        }
                    })
            }else{
                return false;
            }
        })
};

export { updateGGstar, getFromGoogle, getRestaurants, getById, getRestaurantsCrawl,getFilterMenu,countAll };
