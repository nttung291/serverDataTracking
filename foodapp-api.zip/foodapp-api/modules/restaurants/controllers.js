import $fn from '../functions';
import _ from 'lodash';
import mongoose from 'mongoose';
import configs from '../../config';
import request from 'request';
import utf8 from 'utf8';
import rp from 'request-promise';


/**
 * API GET COUNTRIES DISCOVER
 * @route GET /api/countries/discover
 * @group Countries - Operations about Countries
 * @returns {object} 200 - An array of user info
 * @returns {Error}  default - Unexpected error
 */
export const getCountriesDiscover = async (req, res, next) => {
    try {
        const [err, countries] = await $fn.helpers.wait($fn.countries.getCountriesDiscover());
        if (err) return $fn.response.serverError(res, err);
        return $fn.response.success(res, countries);
    } catch (e) {
        console.log(e);
        return $fn.response.serverError(res, e);
    }
};

/**
 * API GET DETAIL RESTAURANTS
 * @route POST /api/restaurant/detail
 * @param {string} param.body.required - {"Id":"5caecc56d9bf51695049a325"}
 * @group Countries - Operations about Countries
 * @returns {object} 200 - An array of user info
 * @returns {Error}  default - Unexpected error
 */
export const getDetail = async (req, res, next) => {
    try {
        let _data = _.pick(req.body, [
            'item',
        ]);
        if (!_data.item) return $fn.response.clientError(res);
        return rp('https://maps.googleapis.com/maps/api/place/textsearch/json?query='+ utf8.encode(_data.item.address) +
         '&key='+configs.google.apikey)
        .then(function (body) {
            let data = JSON.parse(body);
            rp('https://maps.googleapis.com/maps/api/place/details/json?reference='+data.results[0].place_id+'' +
                '&sensor=true&key='+configs.google.apikey)
                .then(function (response) {
                    let result = JSON.parse(response)
                    if (result.result.reviews){
                        $fn.response.success(res, result.result);
                    }else{
                        rp('https://maps.googleapis.com/maps/api/geocode/json?address='+utf8.encode(_data.item.name)+
                            '&bounds='+_data.item.lat+','+_data.item.lng+'|'+_data.item.lat+','+_data.item.lng+'&key='+configs.google.apikey)
                        .then(function (body) {
                            let data = JSON.parse(body);
                            rp('https://maps.googleapis.com/maps/api/place/details/json?reference='+data.results[0].place_id+'' +
                                '&sensor=true&key='+configs.google.apikey)
                                .then(function (response) {
                                    let result = JSON.parse(response);
                                    $fn.response.success(res, result.result);
                                })
                                .catch(function (err) {
                                    $fn.response.success(res);
                                })
                        })
                        .catch(function (err) {
                            $fn.response.success(res);
                        });
                    }
                })
                .catch(function (err) {
                    $fn.response.success(res);
                });
        })
        .catch(function (err) {
            $fn.response.success(res);
        });
        // request('https://maps.googleapis.com/maps/api/place/textsearch/json?query='+ utf8.encode(_data.item.address) +
        //     '&key='+configs.google.apikey
        //     , async (error, response, body) => {
        //         if (!error && response.statusCode == 200 && JSON.parse(body).results[0]) {
        //             let data = JSON.parse(body)
        //             console.log('ve place id',body)
        //             await request('https://maps.googleapis.com/maps/api/place/details/json?reference='+data.results[0].place_id+'&sensor=true&key='+configs.google.apikey
        //                 , async (_error, _response, _body) => {
        //                     if (!error && _response.statusCode == 200) {
        //                         //console.log(JSON.parse(_body));
        //                         let result = JSON.parse(_body)
        //                         return result;
        //                         if (result.result.reviews) $fn.response.success(res, result.result);
        //                     }
        //                 })
        //         }else{
        //             $fn.response.success(res);
        //         }
        //     });
        //  request('https://maps.googleapis.com/maps/api/geocode/json?address='+utf8.encode(_data.item.name)+
        //     '&bounds='+_data.item.lat+','+_data.item.lng+'|'+_data.item.lat+','+_data.item.lng+'+&key='+configs.google.apikey
        //     , async (error, response, body) => {
        //         if (!error && response.statusCode == 200 && JSON.parse(body).results[0]) {
        //             let data = JSON.parse(body)
        //             console.log('vao thu 2');
        //             await request('https://maps.googleapis.com/maps/api/place/details/json?reference='+data.results[0].place_id+'&sensor=true&key='+configs.google.apikey
        //                    , async (_error, _response, _body) => {
        //                        if (!error && _response.statusCode == 200) {
        //                            //console.log(_body);
        //                            let result = JSON.parse(_body)
        //                            if (result.result.reviews) $fn.response.success(res, result.result);
        //                        }
        //                    })
        //         }else{
        //             $fn.response.success(res);
        //         }
        //     })
    } catch (e) {
        console.log(e);
        return $fn.response.success(res, e);
    }
};


/**
 * API GET CITES
 * @route POST /api/restaurants
 * @group Countries - Operations about Countries
 * @param {string} param.body.required - {"city_id":"5caecc4fd9bf51695049a322","name":""}
 * @returns {object} 200 - An array of user info
 * @returns {Error}  default - Unexpected error
 */
export const getRestaurantsForCity = async (req, res, next) => {
    try {
        let _data = req.body;
        if (typeof _data !== 'object') return $fn.response.clientError(res);
        const [err, restarants] = await $fn.helpers.wait($fn.restaurants.getRestaurants(_data));
        if (err) return $fn.response.serverError(res, err);
        return $fn.response.success(res, restarants);
    } catch (e) {
        console.log(e);
        return $fn.response.serverError(res, e);
    }
};

/**
 * API GET RESTAURANTS FOR A CITY
 * @route POST /api/restaurants/menu
 * @group Countries - Operations about Countries
 * @param {string} param.body.required - {"city_id":"5caecc4fd9bf51695049a322" "limit":10}
 * @returns {object} 200 - An array of user info
 * @returns {Error}  default - Unexpected error
 */
export const getMenuFilterCity = async (req, res, next) => {
    try {
        let _data = _.pick(req.body, [
            'city_id',
            'limit'
        ]);
        if (!_data.city_id) return $fn.response.clientError(res);
        const [err, restarants] = await $fn.helpers.wait($fn.restaurants.getFilterMenu(_data.city_id , _data.limit));
        if (err) return $fn.response.serverError(res, err);
        return $fn.response.success(res, restarants);
    } catch (e) {
        console.log(e);
        return $fn.response.serverError(res, e);
    }
};
/**
 * API GET COUNTRIES DISCOVER
 * @route GET /api/countries/discover
 * @group Countries - Operations about Countries
 * @returns {object} 200 - An array of user info
 * @returns {Error}  default - Unexpected error
 */
export const getTracking = async (req, res, next) => {
    try {
        let _data = _.pick(req.body, [
            'dateRangeFrom',
            'dateRangeTo',
            'shipmentReference',
            'destinationPostalCode',
            'fromType',
            'toType',
            'indexType'
        ]);
        let response = [];
        for (let i = parseInt(_data.fromType); i <= parseInt(_data.toType) ; i++){
            let index = i >= 10 ? _data.indexType.slice(1 ,_data.indexType.length) : _data.indexType;
            let condition = {locale: "en_US",
                shipmentType: "Package",
                shipmentReference: `${index}${i}` ,
                shipperAccount: "",
                dateRangeFrom: _data.dateRangeFrom,
                dateRangeTo: _data.dateRangeTo,
                destinationCountry: "us",
                destinationPostalCode: _data.destinationPostalCode ? _data.destinationPostalCode : "33033"};
            let options = {
                method: 'POST',
                uri: 'https://www.ups.com/track/api/Track/GetTrackByReference?loc=en_US',
                body: condition,
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    'User-Agent': 'PostmanRuntime/7.19.0',
                },
                json: true
            };
            await rp(options)
                .then(function (body) {
                    if (body.referenceTrackSummaryDetails !== null){
                        body.referenceTrackSummaryDetails.map((o)=> {
                            response.push(o);
                        });
                    }
                });
        }

        return $fn.response.success(res, response);

    } catch (e) {
        console.log(e);
        return $fn.response.serverError(res, e);
    }
};
