import mongoose from 'mongoose';
import bcrypt from 'mongoose-bcrypt';
import validate from 'mongoose-validator';
import mongoose_delete from 'mongoose-delete';
import timestamps from 'mongoose-timestamp';
import beautifyUnique from 'mongoose-beautiful-unique-validation';
import {getImages} from '../../../../modules/helper/helper';
import configs from '../../../../config';

let logsSchema = new mongoose.Schema({
    page: {
        type: 'Number',
    },
    loop: {
        type: 'Boolean',
        default: true,
    },
});

// userSchema.pre('save', function (next) {
//     if (this.email) this.email = this.email.toLowerCase();
//     next();
// });
//
//
// userSchema.pre('findOneAndUpdate', function (next) {
//     if (this._update.email) this._update.email = this._update.email.toLowerCase();
//     next();
// });

logsSchema.plugin(timestamps);
logsSchema.plugin(beautifyUnique);
logsSchema.plugin(mongoose_delete, {deletedAt: true, overrideMethods: 'all'});

export default mongoose.model('logs_pages', logsSchema);
