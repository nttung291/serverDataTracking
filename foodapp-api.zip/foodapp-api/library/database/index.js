"use strict";

import mongodb from './mongo';

module.exports = {
    mongodb: mongodb,
};
