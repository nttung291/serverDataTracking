'use strict';

import slack from './slack';

module.exports = {
  slack: slack,
};
