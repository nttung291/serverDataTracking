/**
 * The ONLY ES5 file
 */
require('babel-register');
require("babel-polyfill");
require('./schedule');
