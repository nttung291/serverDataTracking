'use strict';

import schedule from 'node-schedule';
import $fn from '../../modules/functions';
import '../database/index';
import configs from '../../config';
import request from 'request';
import utf8 from 'utf8';
schedule.scheduleJob('* * * * *', async () => {
    console.log('Start Schedule * * * * *');
    let [errLogs, Logs] = await $fn.helpers.wait($fn.logs.getPageCrawl());
    if (errLogs) console.log(errLogs);
    if (errLogs || !Logs.page) return false;
    let [errCount, Count] = await $fn.helpers.wait($fn.restaurants.countAll());
    if (errCount) {
        console.log(errCount);
        return false;
    }
    if (Math.round(Count/10) < Logs.page) await $fn.helpers.wait($fn.logs.restartPage(Logs._id));
    let [errRes, Restaurants] = await $fn.helpers.wait($fn.restaurants.getRestaurantsCrawl(
        {limit:10 , page: Logs.page}));
    if (errRes) return false;
    // if (!Restaurants || Restaurants.length < 1) {
    //     await $fn.helpers.wait($fn.logs.restartPage(Logs._id));
    //     return false
    // }
    Restaurants.map(async (item) => {
        request('https://maps.googleapis.com/maps/api/place/textsearch/json?query=' + utf8.encode(item.address) + '&key=' + configs.google.cronjobkey, async (err, response, body) => {
            if (!err && response.statusCode == 200 && JSON.parse(body).results[0]) {
                let data = JSON.parse(body);
                if (data.results[0].rating) {
                    await $fn.helpers.wait($fn.restaurants.updateGGstar({
                        ggrating: Math.round(data.results[0].rating),
                        id: item._id
                    }));
                    console.log('done ', item.name);
                }else{
                    request('https://maps.googleapis.com/maps/api/geocode/json?address='+utf8.encode(item.name)+
                    '&bounds='+item.lat+','+item.lng+'|'+item.lat+','+item.lng+'&key='+configs.google.cronjobkey, async (err, response, body) => {
                        if (!err && response.statusCode == 200 && JSON.parse(body).results[0]) {
                            let data = JSON.parse(body);
                            if (data.results[0].rating) {
                                await $fn.helpers.wait($fn.restaurants.updateGGstar({
                                    ggrating: Math.round(data.results[0].rating),
                                    id: item._id
                                }));
                                console.log('done ', item.name);
                            }
                        }
                    })
                }
            }
            if(err !== null){
                console.log(err);
                //await $fn.helpers.wait($fn.logs.disableCrawl(Logs._id));
            }
        })
    });
    await $fn.helpers.wait($fn.logs.nextPage({id: Logs._id,page : parseInt(Logs.page) + 1}));
});

